console.log('Hello World')
document.write('Hello somehthing')
//window.alert('!!!!')